### Introduction

Welcome to the OpenSceneGraph Qt (osgQT).

This is a Qt project for making use of OpenSceneGraph(OSG)

OSG is required for making use of this project, For up-to-date information on 
the OSG project, in-depth details on how to compile and run libraries and examples, 
see the documentation on the OpenSceneGraph website:

    http://www.openscenegraph.org/index.php/documentation


Known issues:
* This project was forked from the original OSG implementation and needs lots of tidy up
