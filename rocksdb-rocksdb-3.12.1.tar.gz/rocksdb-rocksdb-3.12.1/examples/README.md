Compile RocksDB first by executing `make static_lib` in parent dir
